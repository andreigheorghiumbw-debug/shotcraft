// Background script for ShotCraft
